import { initializeApp } from "firebase/app";
import { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, onAuthStateChanged, User } from "firebase/auth";
import { getFirestore, doc, setDoc, getDoc, updateDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyC4W2Z6EIY1mUD7XlI8stEj31YmXCtyMQI",
  authDomain: "study-95277.firebaseapp.com",
  projectId: "study-95277",
  storageBucket: "study-95277.firebasestorage.app",
  messagingSenderId: "378896937389",
  appId: "1:378896937389:web:7e40f8763891f4336f3124",
  measurementId: "G-YZQNVEW117"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export interface StudyBlock {
  id: string;
  subject: string;
  duration: number;
  color: string;
  icon: string;
}

export async function signUp(email: string, password: string) {
  const userCredential = await createUserWithEmailAndPassword(auth, email, password);
  await setDoc(doc(db, "users", userCredential.user.uid), {
    email: userCredential.user.email,
    blocks: [],
    createdAt: new Date().toISOString()
  });
  return userCredential.user;
}

export async function logIn(email: string, password: string) {
  const userCredential = await signInWithEmailAndPassword(auth, email, password);
  return userCredential.user;
}

export async function logOut() {
  await signOut(auth);
}

export function onAuthChange(callback: (user: User | null) => void) {
  return onAuthStateChanged(auth, callback);
}

export async function getUserBlocks(userId: string): Promise<StudyBlock[]> {
  const docRef = doc(db, "users", userId);
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return docSnap.data().blocks || [];
  }
  return [];
}

export async function saveUserBlocks(userId: string, blocks: StudyBlock[]) {
  const docRef = doc(db, "users", userId);
  await updateDoc(docRef, { blocks });
}
