import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { 
  Plus, 
  Play, 
  Pause, 
  RotateCcw, 
  Clock, 
  BookOpen, 
  Trash2, 
  ChevronRight,
  Sparkles,
  Calendar,
  Timer,
  CheckCircle2,
  LogOut,
  Loader2,
  User
} from "lucide-react";
import { auth, logOut, getUserBlocks, saveUserBlocks, onAuthChange, StudyBlock } from "@/lib/firebase";
import { useLocation } from "wouter";

interface ActiveSession {
  blockId: string;
  startTime: number;
  elapsed: number;
  isPaused: boolean;
}

const SUBJECT_COLORS = [
  { name: "Purple", value: "bg-purple-500", ring: "ring-purple-500/30" },
  { name: "Blue", value: "bg-blue-500", ring: "ring-blue-500/30" },
  { name: "Teal", value: "bg-teal-500", ring: "ring-teal-500/30" },
  { name: "Green", value: "bg-emerald-500", ring: "ring-emerald-500/30" },
  { name: "Orange", value: "bg-orange-500", ring: "ring-orange-500/30" },
  { name: "Pink", value: "bg-pink-500", ring: "ring-pink-500/30" },
  { name: "Red", value: "bg-red-500", ring: "ring-red-500/30" },
  { name: "Yellow", value: "bg-amber-500", ring: "ring-amber-500/30" },
];

const SUBJECT_ICONS = [
  { name: "Math", icon: "📐" },
  { name: "Physics", icon: "⚛️" },
  { name: "Chemistry", icon: "🧪" },
  { name: "Biology", icon: "🧬" },
  { name: "English", icon: "📚" },
  { name: "History", icon: "🏛️" },
  { name: "Geography", icon: "🌍" },
  { name: "Art", icon: "🎨" },
  { name: "Music", icon: "🎵" },
  { name: "Computer", icon: "💻" },
  { name: "Sports", icon: "⚽" },
  { name: "Language", icon: "🗣️" },
];

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

function formatDuration(minutes: number): string {
  if (minutes < 60) return `${minutes} min`;
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [user, setUser] = useState(auth.currentUser);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [blocks, setBlocks] = useState<StudyBlock[]>([]);
  const [activeSession, setActiveSession] = useState<ActiveSession | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newSubject, setNewSubject] = useState("");
  const [newDuration, setNewDuration] = useState("30");
  const [newColor, setNewColor] = useState(SUBJECT_COLORS[0].value);
  const [newIcon, setNewIcon] = useState(SUBJECT_ICONS[0].icon);

  useEffect(() => {
    const unsubscribe = onAuthChange(async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const userBlocks = await getUserBlocks(currentUser.uid);
          setBlocks(userBlocks);
        } catch (err) {
          console.error("Error loading blocks:", err);
        }
      } else {
        setLocation("/auth");
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [setLocation]);

  const saveBlocks = useCallback(async (newBlocks: StudyBlock[]) => {
    if (!user) return;
    setSaving(true);
    try {
      await saveUserBlocks(user.uid, newBlocks);
    } catch (err) {
      console.error("Error saving blocks:", err);
    } finally {
      setSaving(false);
    }
  }, [user]);

  const activeBlock = activeSession 
    ? blocks.find(b => b.id === activeSession.blockId) 
    : null;

  const currentBlockIndex = activeBlock 
    ? blocks.findIndex(b => b.id === activeBlock.id) 
    : -1;

  const nextBlock = currentBlockIndex >= 0 && currentBlockIndex < blocks.length - 1
    ? blocks[currentBlockIndex + 1]
    : null;

  const progress = activeSession && activeBlock
    ? Math.min((activeSession.elapsed / (activeBlock.duration * 60)) * 100, 100)
    : 0;

  const remainingSeconds = activeSession && activeBlock
    ? Math.max(activeBlock.duration * 60 - activeSession.elapsed, 0)
    : 0;

  useEffect(() => {
    if (!activeSession || activeSession.isPaused) return;

    const interval = setInterval(() => {
      setActiveSession(prev => {
        if (!prev) return null;
        const newElapsed = prev.elapsed + 1;
        const block = blocks.find(b => b.id === prev.blockId);
        if (block && newElapsed >= block.duration * 60) {
          return { ...prev, elapsed: block.duration * 60 };
        }
        return { ...prev, elapsed: newElapsed };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [activeSession, blocks]);

  const startSession = useCallback((blockId: string) => {
    setActiveSession({
      blockId,
      startTime: Date.now(),
      elapsed: 0,
      isPaused: false,
    });
  }, []);

  const togglePause = useCallback(() => {
    setActiveSession(prev => prev ? { ...prev, isPaused: !prev.isPaused } : null);
  }, []);

  const resetSession = useCallback(() => {
    setActiveSession(null);
  }, []);

  const moveToNext = useCallback(() => {
    if (nextBlock) {
      startSession(nextBlock.id);
    } else {
      resetSession();
    }
  }, [nextBlock, startSession, resetSession]);

  const addBlock = useCallback(async () => {
    if (!newSubject.trim()) return;
    const newBlock: StudyBlock = {
      id: Date.now().toString(),
      subject: newSubject.trim(),
      duration: parseInt(newDuration) || 30,
      color: newColor,
      icon: newIcon,
    };
    const newBlocks = [...blocks, newBlock];
    setBlocks(newBlocks);
    await saveBlocks(newBlocks);
    setNewSubject("");
    setNewDuration("30");
    setNewColor(SUBJECT_COLORS[0].value);
    setNewIcon(SUBJECT_ICONS[0].icon);
    setIsAddDialogOpen(false);
  }, [newSubject, newDuration, newColor, newIcon, blocks, saveBlocks]);

  const removeBlock = useCallback(async (id: string) => {
    const newBlocks = blocks.filter(b => b.id !== id);
    setBlocks(newBlocks);
    await saveBlocks(newBlocks);
    if (activeSession?.blockId === id) {
      setActiveSession(null);
    }
  }, [activeSession, blocks, saveBlocks]);

  const handleLogout = async () => {
    try {
      await logOut();
      setLocation("/auth");
    } catch (err) {
      console.error("Logout error:", err);
    }
  };

  const totalMinutes = blocks.reduce((sum, b) => sum + b.duration, 0);

  if (loading) {
    return (
      <div className="min-h-screen gradient-soft flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-8 h-8 animate-spin mx-auto text-primary" />
          <p className="text-muted-foreground">Loading your timetable...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen gradient-soft">
      <header className="sticky top-0 z-50 glass border-b border-border/50">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center shadow-md">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight" data-testid="text-app-title">StudyFlow</h1>
              <p className="text-xs text-muted-foreground">Stay focused, stay calm</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {saving && (
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" /> Saving...
              </span>
            )}
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <User className="w-4 h-4" />
              <span className="hidden sm:inline max-w-[150px] truncate">{user?.email}</span>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={handleLogout}
              className="text-muted-foreground"
              data-testid="button-logout"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 py-8 space-y-8">
        <AnimatePresence mode="wait">
          {activeSession && activeBlock ? (
            <motion.div
              key="active-session"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <Card className="p-8 shadow-lg border-0 bg-card/80 backdrop-blur-sm" data-testid="card-active-session">
                <div className="text-center space-y-6">
                  <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                    <Timer className="w-4 h-4" />
                    <span>Currently studying</span>
                  </div>
                  
                  <div className="flex items-center justify-center gap-4">
                    <span className="text-4xl">{activeBlock.icon}</span>
                    <h2 className="text-3xl font-bold tracking-tight" data-testid="text-current-subject">
                      {activeBlock.subject}
                    </h2>
                  </div>

                  <div className="relative w-48 h-48 mx-auto">
                    <svg className="w-full h-full" viewBox="0 0 100 100">
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="6"
                        className="text-muted/30"
                      />
                      <circle
                        cx="50"
                        cy="50"
                        r="45"
                        fill="none"
                        stroke="url(#gradient)"
                        strokeWidth="6"
                        strokeLinecap="round"
                        className="timer-ring"
                        style={{
                          strokeDashoffset: 283 - (283 * progress) / 100,
                        }}
                      />
                      <defs>
                        <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="hsl(252 85% 60%)" />
                          <stop offset="100%" stopColor="hsl(280 75% 55%)" />
                        </linearGradient>
                      </defs>
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-4xl font-bold tabular-nums" data-testid="text-timer">
                        {formatTime(remainingSeconds)}
                      </span>
                      <span className="text-sm text-muted-foreground">remaining</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-3">
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={resetSession}
                      className="rounded-full w-12 h-12 p-0"
                      data-testid="button-reset"
                    >
                      <RotateCcw className="w-5 h-5" />
                    </Button>
                    <Button
                      size="lg"
                      onClick={togglePause}
                      className="rounded-full w-16 h-16 p-0 gradient-primary shadow-lg"
                      data-testid="button-pause-play"
                    >
                      {activeSession.isPaused ? (
                        <Play className="w-6 h-6 text-white ml-1" />
                      ) : (
                        <Pause className="w-6 h-6 text-white" />
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={moveToNext}
                      disabled={!nextBlock && remainingSeconds > 0}
                      className="rounded-full w-12 h-12 p-0"
                      data-testid="button-next"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </Button>
                  </div>

                  {activeSession.isPaused && (
                    <motion.p
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="text-sm text-muted-foreground animate-pulse-soft"
                    >
                      Session paused - take a breather 🌿
                    </motion.p>
                  )}
                </div>
              </Card>

              {nextBlock && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <Card className="p-4 bg-card/60 backdrop-blur-sm border-dashed" data-testid="card-next-up">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="text-muted-foreground text-sm">Up next</div>
                        <div className={`w-2 h-2 rounded-full ${nextBlock.color}`} />
                        <span className="font-medium">{nextBlock.icon} {nextBlock.subject}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">{formatDuration(nextBlock.duration)}</span>
                    </div>
                  </Card>
                </motion.div>
              )}

              {remainingSeconds === 0 && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="text-center"
                >
                  <Card className="p-6 bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800">
                    <div className="flex items-center justify-center gap-2 text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="w-5 h-5" />
                      <span className="font-medium">Session complete! Great work! 🎉</span>
                    </div>
                    {nextBlock ? (
                      <Button
                        onClick={moveToNext}
                        className="mt-4 gradient-primary"
                        data-testid="button-start-next"
                      >
                        Start {nextBlock.subject} <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    ) : (
                      <p className="mt-2 text-sm text-muted-foreground">You've completed all your sessions! 🌟</p>
                    )}
                  </Card>
                </motion.div>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="no-session"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Card className="p-8 shadow-lg border-0 bg-gradient-to-br from-primary/5 via-card to-accent/5" data-testid="card-welcome">
                <div className="text-center space-y-4">
                  <div className="w-16 h-16 mx-auto rounded-2xl gradient-primary flex items-center justify-center shadow-lg">
                    <Sparkles className="w-8 h-8 text-white" />
                  </div>
                  <h2 className="text-2xl font-bold">Ready to focus?</h2>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    Pick a subject from your timetable below to start a study session. 
                    You've got this! 💪
                  </p>
                  <div className="flex items-center justify-center gap-4 pt-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      <span>{blocks.length} sessions</span>
                    </div>
                    <div className="w-1 h-1 rounded-full bg-muted-foreground/30" />
                    <div>{formatDuration(totalMinutes)} total</div>
                  </div>
                </div>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Calendar className="w-5 h-5 text-primary" />
              Your Timetable
            </h3>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2" data-testid="button-add-subject">
                  <Plus className="w-4 h-4" />
                  Add Subject
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Add a Study Block</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="subject">Subject Name</Label>
                    <Input
                      id="subject"
                      placeholder="e.g., Mathematics"
                      value={newSubject}
                      onChange={(e) => setNewSubject(e.target.value)}
                      data-testid="input-subject-name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="duration">Duration (minutes)</Label>
                    <Input
                      id="duration"
                      type="number"
                      min="5"
                      max="180"
                      placeholder="30"
                      value={newDuration}
                      onChange={(e) => setNewDuration(e.target.value)}
                      data-testid="input-duration"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Icon</Label>
                    <div className="flex flex-wrap gap-2">
                      {SUBJECT_ICONS.map(({ icon }) => (
                        <button
                          key={icon}
                          type="button"
                          onClick={() => setNewIcon(icon)}
                          className={`w-10 h-10 rounded-lg flex items-center justify-center text-xl transition-all ${
                            newIcon === icon
                              ? "bg-primary/10 ring-2 ring-primary"
                              : "bg-muted hover:bg-muted/80"
                          }`}
                          data-testid={`button-icon-${icon}`}
                        >
                          {icon}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Color</Label>
                    <div className="flex flex-wrap gap-2">
                      {SUBJECT_COLORS.map(({ name, value, ring }) => (
                        <button
                          key={value}
                          type="button"
                          onClick={() => setNewColor(value)}
                          className={`w-8 h-8 rounded-full ${value} transition-all ${
                            newColor === value ? `ring-4 ${ring}` : ""
                          }`}
                          title={name}
                          data-testid={`button-color-${name.toLowerCase()}`}
                        />
                      ))}
                    </div>
                  </div>
                  <Button 
                    onClick={addBlock} 
                    className="w-full gradient-primary"
                    disabled={!newSubject.trim()}
                    data-testid="button-save-subject"
                  >
                    Add to Timetable
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-3">
            <AnimatePresence>
              {blocks.map((block, index) => {
                const isActive = activeSession?.blockId === block.id;
                const colorClass = SUBJECT_COLORS.find(c => c.value === block.color);
                
                return (
                  <motion.div
                    key={block.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <Card
                      className={`p-4 transition-all cursor-pointer hover:shadow-md ${
                        isActive 
                          ? `ring-2 ${colorClass?.ring || "ring-primary/30"} bg-card` 
                          : "bg-card/70 hover:bg-card"
                      }`}
                      onClick={() => !isActive && startSession(block.id)}
                      data-testid={`card-subject-${block.id}`}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-xl ${block.color} flex items-center justify-center text-2xl shadow-sm`}>
                          {block.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h4 className="font-semibold truncate" data-testid={`text-subject-name-${block.id}`}>
                            {block.subject}
                          </h4>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Clock className="w-3.5 h-3.5" />
                            <span>{formatDuration(block.duration)}</span>
                            {isActive && (
                              <span className="text-primary font-medium animate-pulse-soft">
                                • In progress
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {!isActive && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-muted-foreground hover:text-destructive"
                              onClick={(e) => {
                                e.stopPropagation();
                                removeBlock(block.id);
                              }}
                              data-testid={`button-delete-${block.id}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          )}
                          <Button
                            variant={isActive ? "secondary" : "default"}
                            size="sm"
                            className={isActive ? "" : "gradient-primary text-white"}
                            onClick={(e) => {
                              e.stopPropagation();
                              if (isActive) {
                                togglePause();
                              } else {
                                startSession(block.id);
                              }
                            }}
                            data-testid={`button-start-${block.id}`}
                          >
                            {isActive ? (
                              activeSession?.isPaused ? (
                                <>
                                  <Play className="w-4 h-4 mr-1" /> Resume
                                </>
                              ) : (
                                <>
                                  <Pause className="w-4 h-4 mr-1" /> Pause
                                </>
                              )
                            ) : (
                              <>
                                <Play className="w-4 h-4 mr-1" /> Start
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                      {isActive && activeSession && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          className="mt-4"
                        >
                          <Progress value={progress} className="h-2" />
                          <p className="text-xs text-muted-foreground mt-2 text-center">
                            {formatTime(activeSession.elapsed)} / {formatTime(block.duration * 60)}
                          </p>
                        </motion.div>
                      )}
                    </Card>
                  </motion.div>
                );
              })}
            </AnimatePresence>

            {blocks.length === 0 && (
              <Card className="p-8 border-dashed bg-muted/30">
                <div className="text-center space-y-2">
                  <p className="text-muted-foreground">No subjects yet</p>
                  <p className="text-sm text-muted-foreground/70">
                    Add your first study block to get started!
                  </p>
                </div>
              </Card>
            )}
          </div>
        </div>

        <footer className="text-center pt-8 pb-8 space-y-3">
          <p className="text-sm text-muted-foreground">
            Remember: Progress, not perfection. You're doing great! 🌱
          </p>
          <div className="text-sm text-muted-foreground">
            <p>Made by <span className="font-semibold text-foreground">ESCALMC Team</span></p>
            <a 
              href="https://escalmc.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-primary hover:underline inline-flex items-center gap-1 mt-1"
              data-testid="link-escalmc"
            >
              Visit our website → escalmc.com
            </a>
          </div>
        </footer>
      </main>
    </div>
  );
}
